<?php 
 include_once "constants.php";
 include_once "common.php";

 class Employee{

    public $firstname;
    public $lastname;
    public $role;
	public $dbcon;


    public function __construct(){
        // create object of mysqli

        $this->dbcon = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASENAME);

        if ($this->dbcon->connect_error) {
            die("Failed:".$this->dbcon->connect_error);
        }
    }

    #Sign up the employee
    public function createEmployee($firstname, $lastname, $role) {
        // Check for duplicate entry before inserting
        if ($this->isEmployeeExists($firstname, $lastname)) {
            return false; // Employee already exists
        }
    
        // Prepare statement
        $stmt = $this->dbcon->prepare("INSERT INTO employee (firstname, lastname, role) VALUES (?, ?, ?)");
    
        // Bind parameters to prevent SQL injection
        $stmt->bind_param("sss", $firstname, $lastname, $role);
    
        // Execute the prepared statement
        $stmt->execute();
    
        // Check if the record was inserted successfully
        if ($stmt->affected_rows == 1) {
            return true; // Record inserted successfully
        } else {
            return false; // Error in insertion
            // You can uncomment the line below to get more details about the error
            // return $stmt->error;
        }
    }
    
    // Helper function to check if an employee with the same name already exists
    private function isEmployeeExists($firstname, $lastname) {
        $stmt = $this->dbcon->prepare("SELECT COUNT(*) FROM employee WHERE firstname = ? AND lastname = ?");
        $stmt->bind_param("ss", $firstname, $lastname);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    
        return $count > 0;
    }
    

    #Function to update Employeerole
    
    public function updateEmployeeRole($id){

    $statement=$this->dbcon->prepare("UPDATE employee SET role=?, address=? WHERE id=?");





    }

    #Function to get Job Roles
    public function getRoles() {
        $statement=$this->dbcon->prepare("SELECT * FROM roles ");
    

        $statement->execute();

        $result = $statement->get_result();

        $records = array();

        if($result->num_rows >0){
                while($row = $result->fetch_assoc()){
                    $records[] = $row;
                }

        }

        return $records;
    }
    
    public function createRole($rolename, $roledesc) {
        // Check for duplicate entry before inserting
        if ($this->isRoleExists($rolename, $roledesc)) {
            return false; // Employee already exists
        }
    
        // Prepare statement
        $stmt = $this->dbcon->prepare("INSERT INTO roles (role_name, role_description) VALUES (?, ?)");
    
        // Bind parameters to prevent SQL injection
        $stmt->bind_param("ss", $rolename, $roledesc);
    
        // Execute the prepared statement
        $stmt->execute();
    
        // Check if the record was inserted successfully
        if ($stmt->affected_rows == 1) {
            return true; // Record inserted successfully
        } else {
            return false; // Error in insertion
            // You can uncomment the line below to get more details about the error
            // return $stmt->error;
        }
    }
    
    // Helper function to check if an employee with the same name already exists
    private function isRoleExists($rolename, $roledesc) {

        $stmt = $this->dbcon->prepare("SELECT COUNT(*) FROM roles WHERE role_name = ? AND role_description = ?");
        $stmt->bind_param("ss", $rolename, $roledesc);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    
        return $count > 0;
    }


    #Delete Job Roles
    public function DeleteJobRoles($id){
        $statement = $this->dbcon->prepare("DELETE FROM roles WHERE id = $id ");
           // execute
           $statement->execute();

           if ($statement->affected_rows == 1){
               return true;
           }else{
               return $statement->error;
           }

}


 };
?>
