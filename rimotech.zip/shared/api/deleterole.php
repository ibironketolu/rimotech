<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod == "DELETE") {
    // Get the numeric value directly from the URL
    $id = preg_replace("/[^0-9]/", "", $_SERVER['REQUEST_URI']);

    if ($id !== '') {
        include_once "../signup.php";
        include_once "functions.php";

        $obj = new EmployeeAPI();
        $result = $obj->deleteRole($id);
        
        return $result;
    } else {
        echo json_encode(array('status' => 400, 'message' => 'Bad Request: Missing or invalid "id" parameter'));
    }
} else {
    $data = array(
        'status' => 405,
        'message' => 'Method Not Allowed',
    );
    header("HTTP/1.0 405 Method Not Allowed");
    echo json_encode($data);
}
?>
