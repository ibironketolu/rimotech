<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod == "POST") {
    // Get the role name and description from the POST data
    $rolename = isset($_POST['role_name']) ? $_POST['role_name'] : '';
    $roledesc = isset($_POST['role_desc']) ? $_POST['role_desc'] : '';

    if ($rolename !== '' && $roledesc !== '') {
        include_once "../signup.php";
        include_once "functions.php";

        $obj = new EmployeeAPI();
        $obj->createRole($rolename, $roledesc);
    } else {
        echo json_encode(array('status' => 400, 'message' => 'Bad Request: Missing parameters'));
    }
} else {
    $data = array(
        'status' => 405,
        'message' => 'Method Not Allowed',
    );
    header("HTTP/1.0 405 Method Not Allowed");
    echo json_encode($data);
}
?>
