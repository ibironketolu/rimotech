<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT'); // Assuming you want to use PUT for updates
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestMethod == "PUT") {
    parse_str(file_get_contents("php://input"), $putData);
    
    $id = isset($putData['id']) ? intval($putData['id']) : 0;
    $value = isset($putData['value']) ? intval($putData['value']) : 0; // Adjust this according to your actual data structure

    if ($id > 0) {
        include_once "../signup.php";
        include_once "functions.php";

        $obj = new EmployeeAPI();
        $result = $obj->updateEmployeeStatus($id, $value);
        
        echo json_encode($result);
    } else {
        echo json_encode(array('status' => 400, 'message' => 'Bad Request: Missing or invalid "id" parameter'));
    }
} else {
    $data = array(
        'status' => 405,
        'message' => 'Method Not Allowed',
    );
    header("HTTP/1.0 405 Method Not Allowed");
    echo json_encode($data);
}
?>

