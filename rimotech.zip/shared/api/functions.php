<?php 
 include_once "../constants.php";
 include_once "../common.php";

 class EmployeeAPI {

    public $firstname;
    public $lastname;
    public $role;
	public $dbcon;

	public function __construct(){
			// create object of mysqli

			$this->dbcon = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASENAME);

			if ($this->dbcon->connect_error) {
				die("Failed:".$this->dbcon->connect_error);
			}
		}



        #The function to fetch price list of cod points
        function getEmployeeList() {
            $query = "SELECT * FROM employee";
            
            $statement = $this->dbcon->prepare($query);
        
            $statement->execute();
        
            $result = $statement->get_result();
        
            $output = [];
        
            while($row = $result->fetch_assoc()) {
                $output[] = $row;
            }
        
            header('Content-Type: application/json');
            echo json_encode($output);
        }

        #function to fetch total active roles
        
        function getTotalActiveRoles() {
            $query = "SELECT * FROM roles WHERE active = 1";
            
            $statement = $this->dbcon->prepare($query);
        
            $statement->execute();
        
            $result = $statement->get_result();
        
            $output = [];
        
            while($row = $result->fetch_assoc()) {
                $output[] = $row;
            }
        
            header('Content-Type: application/json');
            echo json_encode($output);
        }



        function deleteRole($id) {
            $query = "DELETE FROM roles WHERE id = ?";
            
            $statement = $this->dbcon->prepare($query);
            $statement->bind_param("i", $id); // Assuming 'id' is an integer
            
            $statement->execute();
            
            if ($statement->affected_rows > 0) {
                // If any rows were affected, the deletion was successful
                $output = array('status' => 'success', 'message' => 'Record successfully deleted');
            } else {
                // If no rows were affected, the record with the given 'id' wasn't found
                $output = array('status' => 'error', 'message' => 'Record not found or deletion failed');
            }
            
            header('Content-Type: application/json');
            echo json_encode($output);
        }
        
        function createRole($rolename, $roledesc){
            $query = "INSERT INTO roles (role_name, role_desc) VALUES (?, ?)";
            
            $statement = $this->dbcon->prepare($query);
            $statement->bind_param("ss", $rolename, $roledesc); // Assuming both parameters are strings
            
            $statement->execute();
            
            if ($statement->affected_rows > 0) {
                // If any rows were affected, the insertion was successful
                $output = array('status' => 'success', 'message' => 'Record successfully created');
            } else {
                // If no rows were affected, the insertion failed
                $output = array('status' => 'error', 'message' => 'Record creation failed');
            }
            
            header('Content-Type: application/json');
            echo json_encode($output);
        }
        
        function updateEmployeeStatus($id, $value) {
            $query = "UPDATE employee SET active = ? WHERE id = ?";
            
            $statement = $this->dbcon->prepare($query);
            $statement->bind_param("ii", $value, $id); // Assuming both parameters are integers
            
            $statement->execute();
            
            if ($statement->affected_rows > 0) {
                // If any rows were affected, the update was successful
                $output = array('status' => 'success', 'message' => 'Record successfully updated');
            } else {
                // If no rows were affected, the record with the given 'id' wasn't found
                $output = array('status' => 'error', 'message' => 'Record not found or update failed');
            }
            
            header('Content-Type: application/json');
            echo json_encode($output);
        }
        

    }