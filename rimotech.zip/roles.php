
<!DOCTYPE html>
<html lang="en">
  <head>

<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
<link rel="icon" type="image/png" href="./assets/img/favicon.png">

<title>
  
   Material Dashboard 2  by Creative Tim
  

  

  
</title>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!-- Bootstrap JS and Popper.js (required for Bootstrap's JavaScript plugins) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy4nBE+Y9tFSVA5cGg4F5g/PD6njsdIRb" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-4s+ctKA1GW9Cc/7VEAa6aD3eF2MKNKX3MP9ZhaeUS9lZnE+Kx+6q+8v9ygZgEIw" crossorigin="anonymous"></script>


<!--     Fonts and icons     -->
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

<!-- Nucleo Icons -->
<link href="./assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="./assets/css/createcss.css" rel="stylesheet" />

<link href="./assets/css/nucleo-svg.css" rel="stylesheet" />

<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

<!-- Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

<!-- CSS Files -->



<link id="pagestyle" href="./assets/css/material-dashboard.css?v=3.1.0" rel="stylesheet" />

<script defer data-site="YOUR_DOMAIN_HERE" src="https://api.nepcha.com/js/nepcha-analytics.js"></script>

  </head>
  <style>

  </style>

  <body class="g-sidenav-show  bg-gray-100">
    

    

    
      <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">

  <div class="sidenav-header">
    <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
    <a class="navbar-brand m-0" href=" https://demos.creative-tim.com/material-dashboard/pages/dashboard " target="_blank">
      <img src="./assets/img/logo-ct.png" class="navbar-brand-img h-100" alt="main_logo">
      <span class="ms-1 font-weight-bold text-white">Material Dashboard 2</span>
    </a>
  </div>


  <hr class="horizontal light mt-0 mb-2">

  <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
    <ul class="navbar-nav">
      

      
        

          

          
  
<li class="nav-item">
  <a class="nav-link text-white " href="dashboard.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">dashboard</i>
      </div>
    
    <span class="nav-link-text ms-1">Dashboard</span>
  </a>
</li>

  
<li class="nav-item">
  <a class="nav-link text-white " href="createemployee.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">table_view</i>
      </div>
    
    <span class="nav-link-text ms-1">Create Employee</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link text-white " href="roles.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">table_view</i>
      </div>
    
    <span class="nav-link-text ms-1">Assign Roles</span>
  </a>
</li>





          

        
      
    </ul>
  </div>
  
  <div class="sidenav-footer position-absolute w-100 bottom-0 ">
    <div class="mx-3">
      <a class="btn btn-outline-primary mt-4 w-100" href="https://www.creative-tim.com/learning-lab/bootstrap/overview/material-dashboard?ref=sidebarfree" type="button">Documentation</a>
      <a class="btn bg-gradient-primary w-100" href="https://www.creative-tim.com/product/material-dashboard-pro?ref=sidebarfree" type="button">Upgrade to pro</a>
    </div>
    
  </div>
  
</aside>

      <main class="main-content border-radius-lg ">
        <!-- Navbar -->

<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
  
</nav>

<!-- End Navbar -->


        


            <div class="container-fluid py-4">
<h6>If you are not redirected automatically, follow <a href=" https://demos.creative-tim.com/material-dashboard/pages/dashboard ">this link</a>.</h6>
<div class="row">
  <div class="col-lg-7 position-relative z-index-2">
    <div class="card card-plain mb-4">
      <div class="card-body p-3">
        <div class="row">
          <div class="col-lg-6">
            <div class="d-flex flex-column h-100">

<!---Php Code for The employee rgistration !--->
<!--- ===========================================
===================================================--->

<?php
        include "shared/signup.php";

        if(isset($_POST['btnCreateJobRole'])) {
            $rolename = $_POST['rolename'];
            $roledesc = $_POST['roledesc'];

            // Instantiate your class (assuming it's named appropriately)
            $roleRegistration = new Employee();

            // Call the signup method
            $result = $roleRegistration->createRole($rolename, $roledesc);

            // Check the result and show a message if needed
            if($result) {
                echo '<p style="color: green;">Role created successfully!</p>';

             } else {
            echo '<p style="color: red;">Registration Failed .....</p>';
            }
        }


?>
          <h2 class="font-weight-bolder mb-0">General Statistics</h2>
          
          <!-- 
            ==================================================
          Form to Create and delete Job roles -->

          <form  href="" method="POST">
            <div class="row clearfix">
                <div class="col">
                <div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
                    <input type="text" name="rolename" placeholder="Role Name"  required />
                </div>
                </div>
                <br>
                <br>
                <div class="col">
                <div class="input_field"> <span><i aria-hidden="true" class="fa fa-user"></i></span>
                    <input type="text" name="roledesc" placeholder="Role Description" required />
                </div>
                </div>
            </div>

            </div>
            <button class="btn-success bg-success"name="btnCreateJobRole" type="submit">Create Role</button>
        </form>
          </div>

          </div>
        </div>
      </div>
    </div>

 <div class="row">
 <div class="form_wrapper">
  <div class="form_container">
    <div class="title_container">
      <h2>Employee Registration Form</h2>
    </div>
    <div class="row clearfix">
      <div class="">
<div class="container table-responsive py-5"> <table class="table table-bordered table-hover">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Job ID</th>
      <th scope="col">Job Roles</th>
      <th scope="col">Description</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <?php
    include_once "shared/signup.php";
    $obj = new Employee();
    $output = $obj->getRoles();

    foreach ($output as $key => $value) {
        $rolename = $value["role_name"];
        $roledescription = $value["role_description"];
        $roleid = $value["id"];

        if (isset($_POST["btnDeleteJob" . $roleid])) {
            $delobj = new Employee();
            $deloutput = $delobj->DeleteJobRoles($roleid);

            if ($deloutput == true) {
                echo "<script>location.reload</script>";
            }
        }
  ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo $roleid   ?></th>
      <td><?php echo $rolename   ?></td>
      <td><?php echo $roledescription   ?></td>
      <td>
        <form action="#" method="POST">
          <!-- Pass the specific role ID as a hidden input -->
          <input type="hidden" name="role_id" value="<?php echo $roleid; ?>">
          <button class="text-danger" name="btnDeleteJob<?php echo $roleid; ?>" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  </tbody>
  <?php
    }
  ?>
</table>

</div>


      </div>
    </div>
  </div>
</div>    </div>



      
      















<!--   Core JS Files   -->
<script src="./assets/js/core/popper.min.js" ></script>
<script src="./assets/js/core/bootstrap.min.js" ></script>
<script src="./assets/js/plugins/perfect-scrollbar.min.js" ></script>
<script src="./assets/js/plugins/smooth-scrollbar.min.js" ></script>











































































<script>
  var win = navigator.platform.indexOf('Win') > -1;
  if (win && document.querySelector('#sidenav-scrollbar')) {
    var options = {
      damping: '0.5'
    }
    Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
  }
</script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>


<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc --><script src="./assets/js/material-dashboard.min.js?v=3.1.0"></script>
  </body>

</html>
